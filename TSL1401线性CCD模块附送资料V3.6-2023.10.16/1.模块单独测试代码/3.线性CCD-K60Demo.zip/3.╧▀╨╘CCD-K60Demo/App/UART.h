#ifndef __UART_H
#define __UART_H

void uart3_init(uint32_t bound);

#endif