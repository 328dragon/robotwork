#ifndef __KEY_H
#define __KEY_H

u8 KEY_Scan(u8 time);

u8 click(void);

u8 Long_Press(void);

u8  select(void);

void KEY_Init(void);



#endif