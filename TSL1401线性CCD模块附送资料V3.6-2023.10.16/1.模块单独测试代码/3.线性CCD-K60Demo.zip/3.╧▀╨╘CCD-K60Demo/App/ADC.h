#ifndef __ADC_H
#define __ADC_H

uint16_t ADC_Get(uint8_t num);

void Test_ADC(void);

#endif