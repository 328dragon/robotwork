#ifndef __TIM1_H
#define __TIM1_H
#include "sys.h"


void Dly_us(void);
void  Find_CCD_Zhongzhi(void);
void RD_TSL(void); 
#endif
