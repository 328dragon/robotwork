#ifndef __TIM1_H
#define __TIM1_H
#include "sys.h"


void Dly_us(void);

#endif
