#ifndef __PIT_H
#define __PIT_H

void MyPIT_Init(void);


#endif