#ifndef __ADC_H
#define __ADC_H	
#include "sys.h"
#include "stm32f10x_adc.h"

void CCD_Init(void);
u16 Get_Adc(u8 ch) ;
void Dly_us(void);
void TIM2_Int_Init(u16 arr, u16 psc);

#endif
